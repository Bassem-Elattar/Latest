@echo off
:: If you're using a portable Java version, uncomment the below two lines and update them to use the correct path
:: set JAVA_HOME=C:\Program Files\Java\jdk-21
:: set path=%JAVA_HOME%\bin;%path%
set path=allure\allure-2.21.0\bin;%path%
allure serve allure-results
pause
exit